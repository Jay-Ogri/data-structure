/* doubly linked list*/
#include<stdio.h>
#include<stdlib.h>
typedef struct dnode{
    int data;
    struct dnode * next;
    struct dnode * prev;
}dnode;
dnode * HP;
dnode * getnode(int x);
dnode * build123();
void print(dnode * s);
void addbegin(dnode * s, int x);
void addend(dnode * s, int x);
void addxbefory(dnode * s, int x, int y);
int nodedelete(dnode * s, int x);
int main(){
    HP = build123();
    addxbefory(HP, 5, 3);
    nodedelete(HP, 1);
    print(HP);
    
    return 0;
}
dnode * getnode(int x){
    dnode * p;
    p = malloc(sizeof(dnode));
    p -> data = x;
    p -> next = NULL;
    p -> prev = NULL;
    return p;
}
dnode * build123(){
    dnode * temp1, * temp2, * temp3;
    temp1 = getnode(1);
    temp2 = getnode(2);
    temp3 = getnode(3);
    temp1 -> next = temp2;
    temp2 -> prev = temp1;
    temp2 -> next = temp3;
    temp3 -> prev = temp2;
    return temp1;
}
void print(dnode * s){
    do{
        printf("%d ", s -> data);
        s = s -> next;
    }while(s != NULL);
    printf("\n");
}
void addbegin(dnode * s, int x){
    dnode * p = getnode(x);
    if(s == NULL){
        HP = p;
        return;
    }
    HP = p;
    p -> next = s;
    s -> prev = p;
}
void addend(dnode * s, int x){
    dnode * p = getnode(x);
    if(s == NULL){
        HP = p;
        return;
    }
    while(s -> next != NULL)
        s = s -> next;
    s -> next = p;
    p -> prev = s;
}
void addxbefory(dnode * s, int x, int y){
    dnode * p = getnode(x);
    if(s == NULL){
        printf("%d does not exis", y);
        free(p);
        return;
    }
    if(s -> data == y){
        HP = p;
        p -> next = s;
        s -> prev = p;
        return;
    }
    while(s -> next != NULL && s -> data != y)
        s = s -> next;
    if(s -> data == y){
        p -> prev = s -> prev;
        s -> prev -> next = p;
        p -> next = s;
        s -> prev = p;
    }
    else{
        printf("%d does not exis", y);
        free(p);
    }
    
}
int nodedelete(dnode * s, int x){
    dnode * q;
    while(s -> data != x && s -> next != NULL){
        q = s;
        s = s -> next;
    }
    if(s -> data == x){
        if(s == HP){
            HP = s -> next;
            s -> next -> prev = NULL;
        }
        else{
            q -> next = s -> next;
            s -> next -> prev = q;
        }
        return x;
    }
    printf("%d do not exist in link", x);
    return -1;
}