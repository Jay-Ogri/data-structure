//Stack implimantation

#include<stdio.h>
#include<conio.h>
#define max 100
int stk[max];
int top;
void init();
void push(int data);
int isempty();
int pop();
void peek();
int main(){
    init();
    push(4);
    push(100);
    push(10);
    peek();
    pop();
    peek();
    
    return 0;
}
void init(){
    top = -1;
}
void push(int data){
    if(top == max-1){
        printf("stack is overflow");
        return;
    }
    stk[++top] = data;
}
int isempty(){
    return (top == -1);
}
int pop(){
    int y;
    if(isempty()){
        printf("the stack is in under flow or is empty");
        return -1;
    }
    y = stk[top--];
    return y;
}
void peek(){
    int i;
    if(isempty()){
        printf("the stack is empty");
        return;
    }
    for(i = 0; i <= top; i++)
        printf(" %d |", stk[i]);
    return;
}