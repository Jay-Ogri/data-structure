// infix to postfix
#include<stdio.h>
#include<conio.h>
#include<string.h>
#define max 100
char stk1[max];
char stk2[max];
int top1, top2;
void init();
void push(char data, int n);
int isempty1();
int isempty2();
char pop(int n);
void peek(int n);
int main() {
	int n, c, j, i, len;
	char eq[max];
	init();
	printf("Enter the equation : ");
	scanf(" %s", eq);
	len = strlen(eq);
	for(i = 0; i < len; i++) {
		if(eq[i] == '(')
			push(eq[i], 2);
		else if(eq[i] == '^')
			push(eq[i], 2);
		else if(eq[i] == '/') {
			while(stk2[top2] == '*' || stk2[top2] == '^')
				push(pop(2), 1);
			push(eq[i], 2);
		}
		else if(eq[i] == '*') {
			while(stk2[top2] == '/' || stk2[top2] == '^')
				push(pop(2), 1);
			push(eq[i], 2);
		}
		else if(eq[i] == '+') {
			while(stk2[top2] == '/' || stk2[top2] == '^' || stk2[top2] == '*' || stk2[top2] == '-')
				push(pop(2), 1);
			push(eq[i], 2);
		}
		else if(eq[i] == '-') {
			while(stk2[top2] == '/' || stk2[top2] == '^' || stk2[top2] == '*' || stk2[top2] == '+')
				push(pop(2), 1);
			push(eq[i], 2);
		}
		else if(eq[i] == ')')
			while(1) {
			    if(stk2[top2] == '(')
			    {
			        pop(2);
					break;
			    }
				push(pop(2), 1);
			}
		else
			push(eq[i], 1);
	}
	while(isempty2() != 1)
		push(pop(2), 1);
	printf("The postfix is : ");
	peek(1);
	


	return 0;
}
void init() {
	top1 = -1;
	top2 = -1;
}
void push(char data, int n) {
	if((top1 == max-1) || (top2 == max-1)) {
		printf("stack is overflow");
		return;
	}
	if(n == 1)
		stk1[++top1] = data;
	if(n == 2)
		stk2[++top2] = data;
}
int isempty1() {
	return (top1 == -1);
}
int isempty2() {
	return (top2 == -1);
}
char pop(int n) {
	char y;
	if(isempty1() || isempty2()) {
		printf("the stack is in under flow or is empty");
		return -1;
	}
	if(n == 1)
		y = stk1[top1--];
	if(n == 2)
		y = stk2[top2--];
	return y;
}
void peek(int n) {
	int i;
	if(n == 1) {
		if(isempty1())
			printf("the stack 1 is empty");
		else {
			for(i = 0; i <= top1; i++)
				printf("%c", stk1[i]);
		}
	}
	printf("\n");
	if(n == 2) {
		if(isempty2())
			printf("\nthe stack 2 is empty");
		else {
			for(i = 0; i <= top2; i++)
				printf(" %c |", stk2[i]);
		}
	}
	return;
}