/* circular queue*/
#include<stdio.h>
#define Max 10
int CQ[Max];
int rear, front;
void init();
void enqueue(int x);
int dequeue();
void display();
int main(){
    init();
    for(int i = 1; i <= Max; i++)
        enqueue(i);
    display();
    dequeue();
    dequeue();
    dequeue();
    dequeue();
    display();
    enqueue(11);
    enqueue(12);
    display();
    return 0;
}
void init(){
    front = -1;
    rear = -1;
}
void enqueue(int x){
    if(front == (rear + 1)%Max){
        printf("Cicluar queue is full(Oveerflow)\n");
        return;
    }
    rear = (rear + 1)%Max;
    CQ[rear] = x;
    if(front == -1)
        front = 0;
}
int dequeue(){
    int y;
    if(front == -1){
        printf("circular queue is empty\n");
        return -1;
    }
    y = CQ[front];
    if(front == rear)
        front = rear = -1;
    else
        front = (front + 1) %Max;
    return y;
}
void display(){
    int i;
    if(front == -1)
            return;
    for(i = front; ((i <= (rear + 1)%Max)||(i >= (rear + 1)%Max)); i = (i + 1)%Max){
        printf(" %d|", CQ[i]);
        if(i == rear)
            break;
    }
    printf("\n");
}