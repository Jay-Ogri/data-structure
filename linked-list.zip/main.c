/*linked list functions*/
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
typedef struct node{
    int data;
    struct node * next;
}node;
node * HP;
node * getnode(int x);
node * build123();
void print(node * s);
void display(node * s);
void addbegin(node * s, int x);
void addend(node * s, int x);
void addxaftery(node * s, int x, int y);
void deletey(node * s, int y);





int main(){
    HP = build123();
    display(HP);
    return 0;
}







node * getnode(int x){
    node * ptr;
    ptr = malloc(sizeof(node));
    ptr -> data = x;
    ptr -> next = NULL;
    return ptr;
}
node * build123(){
    node * temp1, * temp2, * temp3;
    temp1 = getnode(1);
    temp2 = getnode(2);
    temp3 = getnode(3);
    temp1 -> next = temp2;
    temp2 -> next = temp3;
    return temp1;
}
void print(node * s){
    while(s != NULL){
        printf("%d ", s -> data);
        s = s -> next;
    }
}
void display(node * s){
    if(s){
        printf("%d ", s -> data);
        display(s -> next);
    }
}
void addbegin(node * s, int x){
    node * p = getnode(x);
    p -> next = HP;
    HP = p;
}
void addend(node * s, int x){
    node * p = getnode(x);
    if(s){
        while(s -> next)
            s = s -> next;
        s -> next = p;
    }
    else
        HP = p;
}
void addxaftery(node * s, int x, int y){
    node * p = getnode(x);
    if(s == NULL)
        return;
    while(s -> data != y && s -> next != NULL)
        s = s -> next;
    if(s -> data == y){
        p -> next = s -> next;
        s -> next = p;
    }
    else{
        printf("\n%d does not exist", y);
        free(p);
    }
}
void deletey(node * s, int y){
    node * p = NULL;
    if(s == NULL)
        return;
    if(s -> data == y){
        HP = s -> next;
        return;
    }
    while(s -> data != y && s -> next != NULL){
        p = s;
        s = s -> next;
    }
    if(s -> data == y){
        p -> next = s -> next;
        s -> next = NULL;
    }
    else
        printf("%d does not exis", y);
}