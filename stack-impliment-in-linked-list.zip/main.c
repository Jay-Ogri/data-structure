/*implimenting stack In linked list*/
#include<stdio.h>
#include<stdlib.h>
typedef struct node{
    int data;
    struct node * next;
}node;
int top;
void init();
node * HP;
node * getnode(int x);
void print(node * s);
void push(int x);
int pop();
int main(){
    HP = NULL;
    init();
    push(1);
    
    push(2);
    pop();
    pop();
    push(9);
    print(HP);
    
    return 0;
}
int pop(){
    node * s = HP, * q;
    int y;
    if(HP){
        for(int i = 1; i <= top; i++){
            q = s;
            s = s -> next;
        }
        if(top == 0){
            y = HP -> data;
            HP = NULL;
            return y;
        }
        y = s -> data;
        q -> next = NULL;
        top--;
        return y;
    }
    printf("Stack is empty");
    return -1;
}
void push(int x){
    node * p = getnode(x), * s = HP;
    if(HP){
        for(int i = 1; i <= top; i++){
            s = s -> next;
        }
        s -> next = p;
        top++;
        return;
    }
    HP = p;
    top++;
}
node * getnode(int x){
    node * ptr;
    ptr = malloc(sizeof(node));
    ptr -> data = x;
    ptr -> next = NULL;
    return ptr;
}
void print(node * s){
    while(s != NULL){
        printf("%d ", s -> data);
        s = s -> next;
    }
    printf("\n");
}
void init(){
    top = -1;
}